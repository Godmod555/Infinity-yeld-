# Installing Plugins
[Please refer to the wiki](https://github.com/Infinite-Store/Infinite-Store/wiki/Installing-Plugins)
